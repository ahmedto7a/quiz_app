import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:quiz/screens/quiz_screen.dart';

import '../core/auth/auth_bloc.dart';
import 'auth/sign_in/sign_in.dart';


class Dashboard extends StatelessWidget {
  final User currentUser;
  const Dashboard(this.currentUser);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
                length: 2,
                child: Scaffold(
                  appBar: AppBar(
                    centerTitle: true,
                    title: const Text('BLoC Quiz', style: TextStyle(
                      fontSize: 24,
                    ),),
                    backgroundColor: Colors.green,
                    bottom: const TabBar(
                      tabs: [
                        Tab(icon: Icon(Icons.home)),
                        Tab(icon: Icon(Icons.domain_verification)),
                      ],
                    ),
                  ),
                  body: BlocListener<AuthBloc, AuthState>(
                    listener: (context, state) {
                      if (state is UnAuthenticated) {
                        // Navigate to the sign in screen when the user Signs Out
                        Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (context) => SignIn()),
                              (route) => false,
                        );
                      }
                    },
                    child: TabBarView(
                      children: [
                         QuizScreen(),
                        QuizScreen(),
                      ],
                    ),
                  ),
                ));
  }
}
